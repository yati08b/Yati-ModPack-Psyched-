-- Score text config (YatiHUD config) for Yati
-- ver 1.0 (Psych and P-Slice Engine)

function onCreatePost()
setProperty('scoreTxt.visible', true) 
setProperty('scoreTxt.size', '20')  -- Score text size
setProperty('timeBarBG.visible', false) -- time bar background
setProperty('timeBar.visible', false) -- time bar line
setProperty('timeTxt.visible', true) -- time bar text
end

function onCreate()
    lastDownscroll = false
end

function onUpdatePost(elapsed)
-- Score Text Conf 1: Score text Edit
    local score = getProperty('songScore')
    local misses = getProperty('songMisses')
    local rating = getProperty('ratingPercent')
    local ratingName = getProperty('ratingName')
    
    local RatFC = ''
    
    if misses == 0 then
        RatFC = ' [' .. getProperty('ratingFC') .. ']'
    end

    if ratingName == '?' or rating == 0 then
        setTextString('scoreTxt', 'Score: ' .. score .. ' | Combo Breaks: ' .. misses .. ' | Accuracy: --.--% [N/A]')
    else
        local accuracy = round(rating * 100, 2)
        setTextString('scoreTxt', 'Score: ' .. score .. ' | Combo Breaks: ' .. misses .. ' | Accuracy: ' .. accuracy .. '%' .. RatFC)
    end

    -- Score Text Conf 2: text color = opponent health color in healthbar
    local r = getProperty('dad.healthColorArray[0]')
    local g = getProperty('dad.healthColorArray[1]')
    local b = getProperty('dad.healthColorArray[2]')
    local dadHexColor = string.format('%02x%02x%02x', r, g, b)
    setTextColor('scoreTxt', dadHexColor)

    -- Score Text Conf 3: Score text position (disabled)
    --local downscroll = getPropertyFromClass('ClientPrefs', 'downScroll')
    
    --if downscroll ~= lastDownscroll then
    --    lastDownscroll = downscroll
    --    
    --    if downscroll then      -- downscroll enabled
    --        setProperty('scoreTxt.y', 130)                  -- 130 (downscroll ON)
    --        setProperty('scoreTxt.x', screenWidth / 4.5 - 270)      -- 4.5 - center
    --    else                    -- downscroll disabled
    --        setProperty('scoreTxt.y', 130)                  -- 690 (downscroll OFF)
    --        setProperty('scoreTxt.x', screenWidth / 4.5 - 270)      -- 4.5 - center
    --    end
    --end
end

-- accuracy config
function round(num, numDecimalPlaces)
    local mult = 10^(numDecimalPlaces or 0)
    return math.floor(num * mult + 0.5) / mult
end
