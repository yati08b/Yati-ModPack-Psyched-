-- Combo Configuration for Yati
-- ver 1.0 (Psych and P-Slice Engine)


-- Script Part 1: Combo popup enabled and configs
local comboGone = false
local comboOffsetX = 0
local comboOffsetY = -50
local targetCrochet = 680 -- custom BPM value


function onCreatePost()
    setProperty('showCombo', true)      -- combo popup enabled
    setProperty('showComboNum', true)   -- combo score enabled  ( > 0)
    setProperty('showRating', true)     -- combo rating enabled (sick, good, bad, shit)
end

function onUpdatePost(elapsed)
    setPropertyFromClass('backend.Conductor', 'crochet', targetCrochet) -- custom bpm config enabled

    local currentCombo = getProperty('combo')
    
    if currentCombo < 9 then            -- Combo score enable, if combo > 9
        setProperty('showRating', true)
        setProperty('showComboNum', false)
    else
        setProperty('showRating', true)
        setProperty('showComboNum', true)
    end

    if currentCombo < 15 then           -- combo popup enable, if combo > 14
        setProperty('showCombo', false)
    else
        setProperty('showCombo', true)
end



function noteMiss(id, direction, noteType, isSustainNote)   -- Combo popup and score disabled if miss
    setProperty('combo', 0)
    comboGone = true
    end
end

-- Script Part 2: Linking the combo counter to the camera
function onCountdownStarted()
	setObjectCamera('comboGroup', 'camGame')
    setScrollFactor('comboGroup', 1, 1)             -- Do not edit
    callMethod('comboGroup.setPosition', {200,0})   -- can be edited as needed (default: {0,0} )
end