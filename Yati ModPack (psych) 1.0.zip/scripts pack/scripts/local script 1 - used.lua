
local ВЫСОТА = 10

function onCountdownStarted()
    if downscroll then
        
        for enemyStrum = 0, 3 do
            local enemyY = getPropertyFromGroup('strumLineNotes', enemyStrum, 'y')
            setPropertyFromGroup('strumLineNotes', enemyStrum, 'y', enemyY - ВЫСОТА)
        end

        for playerStrum = 4, 7 do
            local playerY = getPropertyFromGroup('strumLineNotes', playerStrum, 'y')
            setPropertyFromGroup('strumLineNotes', playerStrum, 'y', playerY - ВЫСОТА)
        end

    end
end

